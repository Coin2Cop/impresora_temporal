class NumberUtility {
  ///convert number to string , like: 1000 to 'one thousand' or 'هزار'
  static String toWord(String number, NumStrLanguage lang) {
    String _words = "";
    String _result = "";
    if (!_ifullNumber(number)) return "";
    if (number.isEmpty) {
      return '';
    }
    switch (lang) {
      case NumStrLanguage.English:
        _words = _EnWord.toWord(number);
        break;
      case NumStrLanguage.Farsi:
        _words = _FaWord.toWord(number);
        break;
    }
    _result = _words.replaceAll("^\\s+", "").replaceAll("\\b\\s{2,}\\b", " ");
    return _result.trim();
  }

  ///string is numeric or not
  static bool isNumeric(String s) {
    return double.tryParse(s) != null;
  }

  ///convert 123456789 to 123,456,789
  static String seRagham(String number, {String separator = ","}) {
    String str = "";
    number = number.replaceAll(separator, '');
    for (var i = number.length; i > 0;) {
      if (i > 3)
        str = separator + number.substring(i - 3, i) + str;
      else
        str = number.substring(0, i) + str;
      i = i - 3;
    }
    return str;
  }

  ///convert 123456789 to ۱۲۳۴۵۶۷۸۹  Or  ۱۲۳۴۵۶۷۸۹ to 123456789
  static String changeDigit(String number, NumStrLanguage toDigit) {
    var persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    var arabicNumbers = ['٩', '٨', '٧', '٦', '٥', '٤', '٣', '٢', '١', '٠'];
    var enNumbers = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "."];

    if (toDigit == NumStrLanguage.English) {
      for (var i = 0; i < 10; i++) {
        number = number
            .replaceAll(RegExp(persianNumbers[i]), enNumbers[i])
            .replaceAll(RegExp(arabicNumbers[i]), enNumbers[i]);
      }
    } else {
      for (var i = 0; i < 10; i++) {
        number = number
            .replaceAll(RegExp(enNumbers[i]), persianNumbers[i])
            .replaceAll(RegExp(enNumbers[i]), arabicNumbers[i]);
      }
    }
    return number;
  }

  ///extract number from string; abc123456789xyz to ۱۲۳۴۵۶۷۸۹  Or  ابپ۱۲۳۴۵۶۷۸۹ن to 123456789
  static String extractNumber(String inputString, NumStrLanguage toDigit) {
    String number = "";
    number = inputString.replaceAll(RegExp(r'[^0-9]'), ''); // '23'
    return changeDigit(number, toDigit);
  }
}

enum NumStrLanguage { Farsi, English }

bool _ifullNumber(String s) {
  return double.tryParse(s) != null;
}

class _EnWord {
  static String toWord(String inputNumber) {
    int number = int.parse(inputNumber);
    if (number == 0) {
      return "cero";
    }
    String fullNumber = inputNumber;
    for (var i = 0; i < 15 - fullNumber.length; i++) {
      inputNumber = "0" + inputNumber;
    }
    fullNumber = inputNumber;
    int trillion = int.parse(fullNumber.substring(0, 3));
    int billions = int.parse(fullNumber.substring(3, 6));
    int millions = int.parse(fullNumber.substring(6, 9));
    int hundredThousands = int.parse(fullNumber.substring(9, 12));
    int thousands = int.parse(fullNumber.substring(12, 15));

    String tradtrillion;

    switch (trillion) {
      case 0:
        tradtrillion = "";
        break;
      case 1:
        tradtrillion = _convertLessThanOneThousand(trillion) + " Trillon ";
        break;
      default:
        tradtrillion = _convertLessThanOneThousand(trillion) + " Trillon ";
    }
    String result = tradtrillion;

    String tradBillions;

    switch (billions) {
      case 0:
        tradBillions = "";
        break;
      case 1:
        tradBillions = _convertLessThanOneThousand(billions) + " billon ";
        break;
      default:
        tradBillions = _convertLessThanOneThousand(billions) + " billon ";
    }
    result += tradBillions;

    String tradMillions;

    switch (millions) {
      case 0:
        tradMillions = "";
        break;
      case 1:
        tradMillions = _convertLessThanOneThousand(millions) + " millon ";
        break;
      default:
        tradMillions = _convertLessThanOneThousand(millions) + " millones ";
    }
    result = result + tradMillions;

    String tradHundredThousands;
    switch (hundredThousands) {
      case 0:
        tradHundredThousands = "";
        break;
      case 1:
        tradHundredThousands = "mil ";
        break;
      default:
        tradHundredThousands =
            _convertLessThanOneThousand(hundredThousands) + " mil ";
    }
    result = result + tradHundredThousands;

    String tradThousand;
    tradThousand = _convertLessThanOneThousand(thousands);
    result = result + tradThousand;
    return result;
  }

  static String _convertLessThanOneThousand(int number) {
    List<String> tensNames = [
      "",
      " diez",
      " veinte",
      " treinta",
      " cuarenta",
      " cincuenta",
      " sesenta",
      " setenda",
      " ochenta",
      " noventa"
    ];

    List<String> numNames = [
      "",
      " uno",
      " dos",
      " tres",
      " cuatro",
      " cinco",
      " seis",
      " siete",
      " ocho",
      " nueve",
      " diez",
      " once",
      " doce",
      " trece",
      " catorce",
      " quince",
      " dieciséis",
      " diecisiete",
      " dieciocho",
      " diecinueve"
    ];
    String soFar;
    if (number % 100 < 20) {
      soFar = numNames[number % 100];
      number = number ~/ 100;
    } else {
      soFar = numNames[number % 10];
      number = number ~/ 10;
      soFar = tensNames[number % 10] + soFar;
      number = number ~/ 10;
    }
    if (number == 0) return soFar;
    return numNames[number] + " cientos" + soFar;
  }
}

class _FaWord {
  static String toWord(String inputNumber) {
    int number = int.parse(inputNumber);
    if (number == 0) {
      return "صفر";
    }
    String fullNumber = inputNumber;
    for (var i = 0; i < 15 - fullNumber.length; i++) {
      inputNumber = "0" + inputNumber;
    }
    fullNumber = inputNumber;

    int trillion = int.parse(fullNumber.substring(0, 3));
    int billions = int.parse(fullNumber.substring(3, 6));
    int millions = int.parse(fullNumber.substring(6, 9));
    int hundredThousands = int.parse(fullNumber.substring(9, 12));
    int thousands = int.parse(fullNumber.substring(12, 15));

    String tradtrillion;

    switch (trillion) {
      case 0:
        tradtrillion = "";
        break;
      case 1:
        tradtrillion = _convertLessThanOneThousand(trillion) + " تریلیون ";
        break;
      default:
        tradtrillion = _convertLessThanOneThousand(trillion) + " تریلیون و";
    }
    String result = tradtrillion;

    String tradBillions;

    switch (billions) {
      case 0:
        tradBillions = "";
        break;
      default:
        tradBillions = _convertLessThanOneThousand(billions) + " میلیارد و";
    }
    result += tradBillions;

    String tradMillions;

    switch (millions) {
      case 0:
        tradMillions = "";
        break;
      default:
        tradMillions = _convertLessThanOneThousand(millions) + " میلیون و";
    }
    result = result + tradMillions;

    String tradHundredThousands;
    switch (hundredThousands) {
      case 0:
        tradHundredThousands = "";
        break;
      case 1:
        tradHundredThousands = "هزار و";
        break;
      default:
        tradHundredThousands =
            _convertLessThanOneThousand(hundredThousands) + " هزار و";
    }
    result = result + tradHundredThousands;

    String tradThousand;
    tradThousand = _convertLessThanOneThousand(thousands);
    result = result + tradThousand;

    if (result.endsWith(" و")) {
      result = result.substring(0, result.length - 2);
    }

    return result;
  }

  static String _convertLessThanOneThousand(int number) {
    List<String> tensNames = [
      "",
      " ده و",
      " بیست و",
      " سی و",
      " چهل و",
      " پنجاه و",
      " شصت و",
      " هفتاد و",
      " هشتاد و",
      " نود و"
    ];

    List<String> numNames = [
      "",
      " یک",
      " دو",
      " سه",
      " چهار",
      " پنج",
      " شش",
      " هفت",
      " هشت",
      " نه",
      " ده",
      " یازده",
      " دوازده",
      " سیزده",
      " چهارده",
      " پانزده",
      " شانزده",
      " هفده",
      " هجده",
      " نوزده"
    ];

    List<String> thousandsNames = [
      "",
      " صد و",
      " دویست و",
      " سیصد و",
      " چهارصد و",
      " پانصد و",
      " ششصد و",
      " هفتصد و",
      " هشتصد و",
      " نهصد و"
    ];
    String soFar;
    if (number % 100 < 20) {
      soFar = numNames[number % 100];
      number = number ~/ 100;
    } else {
      soFar = numNames[number % 10];
      number = number ~/ 10;
      soFar = tensNames[number % 10] + soFar;
      number = number ~/ 10;
    }
    if (number == 0) {
      if (soFar.endsWith(" و")) {
        soFar = soFar.substring(0, soFar.length - 2);
      }
      return soFar;
    }
    var str = "";
    str = (thousandsNames[number] + soFar);
    if (str.endsWith(" و") || str.endsWith("و ")) {
      str = str.substring(0, str.length - 2);
    }
    return str;
  }
}